create function rpad(text, integer) returns text
    immutable
    strict
    parallel safe
    cost 1
    language sql
as
$$
    begin
-- missing source code
end;
$$;

comment on function rpad(text, integer, text) is 'right-pad string to length';

alter function rpad(text, integer, text) owner to postgres;

